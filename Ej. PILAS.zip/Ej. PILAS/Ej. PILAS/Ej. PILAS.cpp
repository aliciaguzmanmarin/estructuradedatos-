// Ej. PILAS.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "Pila.h"
#include <string>
#include <iostream>
 using namespace std;

void main()
{   string a ; bool k ; int n,cont=0 ;
	Pila P ;
	do {cout<<"ingrese elemento : ";
	cin>>a ;
	k=P.Apilar(a);}
	while (k==true);
	P.MostrarPila();
	cout<<"elementos a desapilar :";cin>>n;
	do {
	    P.Desapilar(a);
	    cont++;
	   }
	while (cont<n);
	P.MostrarPila();
  getch();
}
