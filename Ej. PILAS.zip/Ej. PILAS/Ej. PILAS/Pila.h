#pragma once
#include <string>
 using namespace std;
class Pila
{
private:
	string A[5] ;
	int tope;
public:
	Pila(void);
	~Pila(void);
	bool Apilar (string dato);
	bool Desapilar (string &dato);
	bool MostrarPila();
};

