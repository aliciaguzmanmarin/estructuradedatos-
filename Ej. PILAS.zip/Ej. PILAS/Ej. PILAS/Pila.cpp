#include "StdAfx.h"
#include "Pila.h"
#include <iostream>
#include <string>
 using namespace std;

Pila::Pila(void)
{ tope = -1 ;
}

Pila::~Pila(void)
{
}

bool Pila::Apilar(string dato)
{ if (tope == (5-1))
    {cout<<"la pila esta llena "<<dato<<" no ingresado ";
     return false ; 
    }
else { tope++;
      A[tope]=dato;
	  return true ;
     }
}

bool Pila::Desapilar(string &dato)
{ if (tope==-1)
    {cout<<"la pila esta vacia "<<endl;
     return false ; 
    }
else { dato=A[tope];
       tope--;
     } return true ;
}

bool Pila::MostrarPila()
{ cout<<endl;
	for (int i=0 ; i<=tope ; i++)
    { cout<<A[tope-i]<<endl;
    }return true ;
}